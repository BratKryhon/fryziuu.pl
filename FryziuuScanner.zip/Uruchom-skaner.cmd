@echo off
chcp 65001 >nul
title Fryziuu Scanner - Minecraft
echo Uruchamianie Fryziuu Scanner...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0FryziuuScanner.ps1"
