﻿# Fryziuu Scanner - jawny, tylko do odczytu skaner artefaktow Minecraft
$ErrorActionPreference = "SilentlyContinue"
$Host.UI.RawUI.WindowTitle = "Fryziuu Scanner - analiza Minecraft"
$KnownClients = @(
 "Doomsday","Grim","Aristois","RWD","Rise","Vape","Drip","Moon","Entropy",
 "Wurst","LiquidBounce","ThunderHack","Akrien","Exodus","Vestige","Sigma",
 "Meteor","Impact","BleachHack","Raven","Myau","Future","Kami","Inertia",
 "Wolfram","Phobos","Astolfo","Tenacity","Prestige","Novoline","Krypton",
 "Ares","FDPClient","Xatz","Wild","Zamorozka","Huzuni","Jigsaw","Flux",
 "Eject","Dream","Slinky","Rise","Augustus","Ketamine","Dream client"
)
$Evidence = [System.Collections.Generic.List[object]]::new()
$Checks = [System.Collections.Generic.List[object]]::new()
$script:Step=0; $script:Total=7
function Step($label) {
 $script:Step++
 $pct=[int](($script:Step/$script:Total)*100)
 Write-Progress -Activity "Fryziuu Scanner - skanowanie" -Status "$label ($pct%)" -PercentComplete $pct
 Write-Host ("[{0,3}%] {1}" -f $pct,$label) -ForegroundColor Cyan
}
function Add-Evidence($type,$name,$detail,$level,$path="") {
 $Evidence.Add([pscustomobject]@{type=$type;name=$name;detail=$detail;level=$level;path=$path})
}
function Add-Check($name,$result,$detail) {
 $Checks.Add([pscustomobject]@{name=$name;result=$result;detail=$detail})
}
function HashFile($p) { try {(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash} catch {""} }

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host "             FRIZIUU SCANNER" -ForegroundColor Green
Write-Host "       Minecraft / Windows Forensics" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host "Skan jest tylko do odczytu. Niczego nie usuwa." -ForegroundColor Gray
Write-Host "Administrator nie gwarantuje pelnej wykrywalnosci." -ForegroundColor Yellow
Write-Host ""

Step "Wyszukiwanie procesu Java / Minecraft"
$procs=@(Get-CimInstance Win32_Process | Where-Object {$_.Name -in @("javaw.exe","java.exe") -and $_.CommandLine -match '(?i)minecraft|net\.minecraft|fabric|forge|neoforge|quilt'})
$proc=$procs | Select-Object -First 1
$nick="Nieustalony"; $version="Nieustalona"; $client="Nieustalony"
if($proc) {
 Add-Check "Proces Java" "ZNALEZIONO" "PID $($proc.ProcessId), $($proc.Name)"
 if($proc.CommandLine -match '(?i)--username\s+"?([^"\s]+)') {$nick=$Matches[1]}
 if($proc.CommandLine -match '(?i)--version\s+"?([^"\s]+)') {$version=$Matches[1]}
 Add-Evidence "Proces" "Minecraft Java" "Wykryto proces $($proc.Name), PID $($proc.ProcessId)." "info"
} else {Add-Check "Proces Java" "NIE ZNALEZIONO" "Uruchom Minecraft przed skanowaniem."}

Step "Ustalanie katalogu instancji i logow"
$gameDir="$env:APPDATA\.minecraft"
if($proc -and $proc.CommandLine -match '(?i)--gameDir\s+"([^"]+)"') {$gameDir=$Matches[1]}
if(!(Test-Path $gameDir)) {$gameDir="$env:APPDATA\.minecraft"}
$log=Join-Path $gameDir "logs\latest.log"
if(Test-Path $log) {
 $logText=Get-Content -LiteralPath $log -Raw
 if($logText -match '(?i)Minecraft\s+([0-9]+\.[0-9]+(?:\.[0-9]+)?)') {$version=$Matches[1]}
 if($logText -match '(?i)Setting user:\s*([A-Za-z0-9_]{1,16})') {$nick=$Matches[1]}
 Add-Check "Log latest.log" "ODCZYTANO" "Odczytano lokalny log gry."
} else {Add-Check "Log latest.log" "BRAK" "Nie znaleziono latest.log w wykrytym katalogu."}

Step "Skanowanie plikow JAR w instancji"
$jars=@()
if(Test-Path $gameDir) {$jars=@(Get-ChildItem -LiteralPath $gameDir -Filter *.jar -File -Recurse | Select-Object -First 1500)}
foreach($f in $jars) {
 foreach($c in $KnownClients) {
  if($f.Name -match [regex]::Escape($c)) {
   Add-Evidence "Nazwa pliku JAR" $c "Nazwa pliku pasuje do nazwy znanego klienta; to wskaznik, nie dowod." "medium" $f.FullName
   break
  }
 }
}
Add-Check "Pliki JAR" "ZAKONCZONO" "Sprawdzono $($jars.Count) plikow JAR (limit 1500)."

Step "Analiza nazw modow i bibliotek"
$modDirs=@((Join-Path $gameDir "mods"),(Join-Path $gameDir "libraries"))
foreach($dir in $modDirs) {
 if(Test-Path $dir) {
  Get-ChildItem -LiteralPath $dir -File -Recurse | ForEach-Object {
   $file=$_
   foreach($c in $KnownClients) {
    if($file.Name -match [regex]::Escape($c)) {
     Add-Evidence "Artefakt plikowy" $c "Nazwa pliku pasuje do znanej nazwy klienta." "medium" $file.FullName
     break
    }
   }
  }
 }
}
Add-Check "Foldery mods/libraries" "ZAKONCZONO" "Sprawdzono nazwy plikow w katalogach modow i bibliotek."

Step "Analiza argumentow JVM"
if($proc -and $proc.CommandLine) {
 if($proc.CommandLine -match '(?i)-javaagent:') {Add-Evidence "Argument JVM" "javaagent" "Wykryto parametr javaagent. Moze byc legalnym narzedziem; sprawdz sciezke." "medium"}
 if($proc.CommandLine -match '(?i)-agentlib:|jdwp=') {Add-Evidence "Argument JVM" "Agent/debug" "Wykryto argument agenta/debugowania JVM." "low"}
 Add-Check "Argumenty JVM" "ODCZYTANO" "Dostepne argumenty procesu Java zostaly sprawdzone."
} else {Add-Check "Argumenty JVM" "NIEDOSTEPNE" "Brak procesu lub brak dostepu do argumentow."}

Step "Sprawdzanie dostepnych modulow procesu"
if($proc) {
 try {
  $mods=(Get-Process -Id $proc.ProcessId).Modules
  $count=0
  foreach($m in $mods) {
   $count++
   if($m.FileName -match '(?i)\\(temp|downloads)\\') {
    Add-Evidence "Modul procesu" "Modul z katalogu tymczasowego" "Modul zaladowany z lokalizacji uzytkownika/tymczasowej; wymaga weryfikacji." "low" $m.FileName
   }
  }
  Add-Check "Widoczne moduly" "ODCZYTANO" "Widocznych modulow: $count"
 } catch {Add-Check "Widoczne moduly" "CZESCIOWO" "Windows odmowil dostepu lub modulow nie mozna odczytac."}
} else {Add-Check "Widoczne moduly" "POMINIETO" "Nie znaleziono procesu."}

Step "Budowanie werdyktu i raportu"
$med=@($Evidence|Where-Object level -eq "medium").Count
$low=@($Evidence|Where-Object level -eq "low").Count
$verdict="BRAK WYKRYTYCH WSKAZNIKOW"
if($med -ge 2) {$verdict="PODEJRZANY - WYMAGA WERYFIKACJI"} elseif($med -ge 1 -or $low -gt 0) {$verdict="NIEJEDNOZNACZNY - WYMAGA WERYFIKACJI"}
if(!$proc) {$verdict="SKAN NIEPELNY - NIE WYKRYTO MINECRAFT"}
$report=[pscustomobject]@{
 product="Fryziuu Scanner";version="2.1";scanTime=(Get-Date).ToString("o")
 verdict=$verdict;client=$client;gameVersion=$version;nickname=$nick
 process=if($proc){"$($proc.Name), PID $($proc.ProcessId)"}else{"Nie znaleziono"}
 instancePath=$gameDir;evidence=@($Evidence);checks=@($Checks)
 limitations=@("To skan heurystyczny; nie wykrywa niezawodnie kazdego injectora ani kodu w pamieci.","Nie mozna potwierdzic, ze dany cheat zostal injectowany, na podstawie samego JAR lub nazwy procesu.","Zmodyfikowane, ukryte i nieznane klienty moga nie zostac wykryte.","Administrator nie daje 100% dokladnosci.","Brak wskaznikow nie jest dowodem uczciwej gry.")
}
$out=Join-Path $PSScriptRoot "FryziuuReport.json"
$report|ConvertTo-Json -Depth 7|Set-Content -Encoding UTF8 $out
Write-Progress -Activity "Fryziuu Scanner" -Completed
Write-Host ""
Write-Host "============== WERDYKT ==============" -ForegroundColor Green
Write-Host $verdict -ForegroundColor Yellow
Write-Host "Nick: $nick"
Write-Host "Wersja: $version"
Write-Host "Client: $client"
Write-Host "Wskazniki: $($Evidence.Count)"
Write-Host "Raport: $out"
Write-Host "=====================================" -ForegroundColor Green
# Generate a standalone Polish HTML report that opens automatically
$evHtml=($Evidence|ForEach-Object {"<li><b>$([System.Net.WebUtility]::HtmlEncode($_.name))</b> - $([System.Net.WebUtility]::HtmlEncode($_.detail))<br><small>$([System.Net.WebUtility]::HtmlEncode($_.path))</small></li>"}) -join "`n"
$html=@"
<!doctype html><html lang="pl"><meta charset="utf-8"><title>Raport Fryziuu</title>
<style>body{background:#0b1118;color:#edf4fa;font:16px Segoe UI,Arial;max-width:900px;margin:40px auto;padding:20px}section{background:#141f2b;border:1px solid #304052;border-radius:16px;padding:22px;margin:14px 0}.v{font-size:25px;color:#ffd27b;font-weight:bold}li{padding:12px;border-bottom:1px solid #304052}small{color:#9baabd;overflow-wrap:anywhere}</style>
<h1>FRIZIUU SCANNER - RAPORT</h1><section><div class="v">$verdict</div><p>Nick: $nick</p><p>Wersja: $version</p><p>Client: $client</p><p>Proces: $($report.process)</p></section>
<section><h2>Wykryte wskazniki</h2><ul>$evHtml</ul></section><section><h2>Wazne ograniczenia</h2><ul><li>Brak wskaznikow nie gwarantuje braku cheatow.</li><li>Skan nie potwierdza wstrzykniecia kodu do pamieci.</li><li>Wyniki wymagaja recznej weryfikacji.</li></ul></section></html>
"@
$html|Set-Content -Encoding UTF8 (Join-Path $PSScriptRoot "Wynik.html")
Start-Process (Join-Path $PSScriptRoot "Wynik.html")
Write-Host "`nNacisnij dowolny klawisz, aby zamknac..." -ForegroundColor Gray
[void][Console]::ReadKey($true)
