FRIZIUU SCANNER - INSTRUKCJA
1. Rozpakuj folder.
2. Uruchom Minecraft i zostaw go wlaczonego.
3. Kliknij dwukrotnie Uruchom-skaner.cmd.
4. Okno CMD pokazuje etapy i postep skanowania.
5. Po zakonczeniu automatycznie otworzy sie Wynik.html.
6. FryziuuReport.json zawiera dane raportu.

Program jest tylko do odczytu. Nie wymaga administratora do podstawowych kontroli.
Nie gwarantuje wykrycia 90% ani 100% cheatow. Nie potwierdza injection do pamieci.
Nick i wersja sa odczytywane z argumentow JVM/logow, jesli sa dostepne.
Nie uzywaj raportu jako jedynego dowodu do ukarania gracza.
